from flask import Flask, request
from flask_cors import CORS, cross_origin
import serial

import json

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
dataSerial = serial.Serial('COM4', 115200)

@app.route('/')
def home():
    return 'data'

@app.route('/camera',  methods=['POST', 'GET'])
@cross_origin()
def camera():
    if request.method == 'POST':
        print('post from ajax')
        output = request.get_json()
        print(output) # This is the output that was stored in the JSON within the browser
        # print(type(output))
        # print(output["object_name"])
        object_name = output["object_name"]
        print(object_name)
        print(type(object_name))
        getSound(object_name)
        # result = json.loads(output) #this converts the json output to a python dictionary
        # print(result) # Printing the new dictionary
        # print(type(result))#this shows the json converted as a python dictionary

        # if (result):
        #     return 'result: ' + result
        return "output: " + object_name

    if request.method == 'GET':
        return 'null'

def getSound(objek):
    if objek == "refrigerator":
        dataSerial.write(b"mobil")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "oven":
        dataSerial.write(b"meja")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "chair":
        dataSerial.write(b"kursi")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "person":
        dataSerial.write(b"mobil")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data

if __name__ == '__main__':
    app.run()
