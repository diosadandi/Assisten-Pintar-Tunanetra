from flask import Flask, request
from flask_cors import CORS, cross_origin
import serial
import time

import json

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
dataSerial = serial.Serial('COM3', 115200)

@app.route('/')
def home():
    return 'data'

@app.route('/camera',  methods=['POST', 'GET'])
@cross_origin()
def camera():
    if request.method == 'POST':
        print('post from FETCH')
        output = request.get_json()
        print(output) # This is the output that was stored in the JSON within the browser
        # print(type(output))
        # print(output["object_name"])
        object_name = output["object_name"]


        print(object_name)
        print(type(object_name))
        print("send object name to speaker")
        getSound(object_name)
    #solusinya adalah membuat set clear python .clear() dan membuat if jika lolos panggil function getsound sebaliknya gunkana .clear untuk membuang inputan sebelum 2 detik
        # result = json.loads(output) #this converts the json output to a python dictionary
        # print(result) # Printing the new dictionary
        # print(type(result))#this shows the json converted as a python dictionary

        # if (result):
        #     return 'result: ' + result
        return "output: " + object_name

    if request.method == 'GET':
        return 'null'


# @app.route('/objek',  methods=['GET'])
# @cross_origin()
# def speaker(cape):
#     # Data to be written
#     dictionary ={
#         "postId": 1,
#         "id": 10,
#         "name": "eaque et deleniti atque tenetur ut quo ut",
#         "email": "Carmen_Keeling@caroline.name",
#         "body": "voluptate iusto quis nobis reprehenderit ipsum amet nulla\nquia quas dolores velit et non\naut quia necessitatibus\nnostrum quaerat nulla et accusamus nisi facilis"
#     }
#
#     return json.dumps(dictionary, indent=4)
#
#     # with open("dictionary.json", "w") as file_object:
#     #     kirim = json.dump(dictionary, file_object)
#     #
#     # print(kirim)




def getSound(objek):
    if objek == "person":
        dataSerial.write(b"orang")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bicycle":
        dataSerial.write(b"sepeda")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "car":
        dataSerial.write(b"mobil")
        esp32_data = dataSerial.readline().decode('ascii')
        # return esp32_data
        print("mobil")
    elif objek == "motorcycle":
        dataSerial.write(b"motor")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "airplane":
        dataSerial.write(b"pesawat")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bus":
        dataSerial.write(b"bis")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "train":
        dataSerial.write(b"kereta")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "truck":
        dataSerial.write(b"truk")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "boat":
        dataSerial.write(b"perahu")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "traffic light":
        dataSerial.write(b"lalin")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "fire hydrant":
        dataSerial.write(b"fire hydrant")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "stop sign":
        dataSerial.write(b"tanda berhenti")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "parikng meter":
        dataSerial.write(b"meteran parkiran")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bench":
        dataSerial.write(b"bangku")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bird":
        dataSerial.write(b"burung")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "cat":
        dataSerial.write(b"kucing")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "dog":
        dataSerial.write(b"anjing")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "horse":
        dataSerial.write(b"kuda")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "sheep":
        dataSerial.write(b"domba")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "cow":
        dataSerial.write(b"sapi")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "elephant":
        dataSerial.write(b"gajah")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bear":
        dataSerial.write(b"beruang")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "zebra":
        dataSerial.write(b"zebra")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "giraffe":
        dataSerial.write(b"jerapah")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "backpack":
        dataSerial.write(b"ransel")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "umbrella":
        dataSerial.write(b"payung")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "handbag":
        dataSerial.write(b"tas tangan")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "tie":
        dataSerial.write(b"dasi")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "suitcase":
        dataSerial.write(b"koper")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "frisbee":
        dataSerial.write(b"frisbee")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "skis":
        dataSerial.write(b"ski")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "snowboard":
        dataSerial.write(b"papas seluncur es")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "sports ball":
        dataSerial.write(b"bola")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "kite":
        dataSerial.write(b"layangan")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "baseball bat":
        dataSerial.write(b"pemukul baseball")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "baseball glove":
        dataSerial.write(b"sarung tangan baseball")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "skateboard":
        dataSerial.write(b"papan seluncur")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "surfboard":
        dataSerial.write(b"papan seluncur air")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "tennis racket":
        dataSerial.write(b"raket tenis")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bottle":
        dataSerial.write(b"botol")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "wine glass":
        dataSerial.write(b"gelas mabuk")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "cup":
        dataSerial.write(b"cangkir")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "fork":
        dataSerial.write(b"garpu")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "knife":
        dataSerial.write(b"pisau")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "spoon":
        dataSerial.write(b"sendok")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bowl":
        dataSerial.write(b"mangkok")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "banana":
        dataSerial.write(b"pisang")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "apple":
        dataSerial.write(b"apel")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "sandwich":
        dataSerial.write(b"roti isi")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "orange":
        dataSerial.write(b"jeruk")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "broccoli":
        dataSerial.write(b"brokoli")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "carrot":
        dataSerial.write(b"wortel")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "hot dog":
        dataSerial.write(b"hot dog")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "pizza":
        dataSerial.write(b"pizza")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "donut":
        dataSerial.write(b"donat")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "cake":
        dataSerial.write(b"kue")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "chair":
        dataSerial.write(b"kursi")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "couch":
        dataSerial.write(b"sofa")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "potted plant":
        dataSerial.write(b"tanaman pot")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "bed":
        dataSerial.write(b"kasur")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "dining table":
        dataSerial.write(b"meja makan")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "toilet":
        dataSerial.write(b"toilet")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "tv":
        dataSerial.write(b"tv")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "laptop":
        dataSerial.write(b"laptop")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "remote":
        dataSerial.write(b"remote")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "mouse":
        dataSerial.write(b"mouse")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "keyboard":
        dataSerial.write(b"keyboard")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "cell phone":
        dataSerial.write(b"hp")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "microwave":
        dataSerial.write(b"gelombang pendek")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "oven":
        dataSerial.write(b"oven")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "toaster":
        dataSerial.write(b"panggangan roti")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "sink":
        dataSerial.write(b"westafel")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "refrigerator":
        dataSerial.write(b"kulkas")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "book":
        dataSerial.write(b"buku")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "clock":
        dataSerial.write(b"jam")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "vase":
        dataSerial.write(b"vas bunga")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "scissors":
        dataSerial.write(b"gunting")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "teddy bear":
        dataSerial.write(b"boneka teddy bear")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "hair drier":
        dataSerial.write(b"pengering rambut")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data
    elif objek == "toothbrush":
        dataSerial.write(b"sikat gigi")
        esp32_data = dataSerial.readline().decode('ascii')
        return esp32_data


if __name__ == '__main__':
    app.run(host='0.0.0.0')
